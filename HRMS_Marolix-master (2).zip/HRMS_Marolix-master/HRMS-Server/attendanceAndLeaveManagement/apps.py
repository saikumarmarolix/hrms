from django.apps import AppConfig


class AttendanceandleavemanagementConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'attendanceAndLeaveManagement'
